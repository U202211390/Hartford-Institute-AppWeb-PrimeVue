export class Patient {
    constructor(id, firstName, lastName, photoUrl, birthDate){
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.photoUrl = photoUrl;
        this.birthDate = birthDate;
    }

}